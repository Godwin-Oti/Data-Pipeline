import os
import psycopg2
import json

def save_bitcoin_data(event, context):
    Database_URL = os.getenv('DataBase_Url')
    
    try:
        conn = psycopg2.connect(Database_URL)
        cursor = conn.cursor()
        
        # Parse the incoming event
        data = json.loads(event['body'])
        
        for date, values in data.items():
            cursor.execute('''
                INSERT INTO Bitcoin_Prices_Update(Date, Open, High, Low, Close, Volume)
                Values(%s, %s, %s, %s, %s, %s)
                ON CONFLICT (Date) DO NOTHING
                ''', (date, values['1. open'], values['2. high'], values['3. low'], values['4. close'], values['5. volume']))
        
        conn.commit()
        cursor.close()
        return {
            'statusCode': 200,
            'body': json.dumps('Success')
        }
    except Exception as e:
        print(f'Error inserting Bitcoin data: {e}')
        conn.rollback()
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error inserting Bitcoin data: {e}')
        }
    finally:
        if conn:
            conn.close()
